echo "zzAllScripts.sh"
