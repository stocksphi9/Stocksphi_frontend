export const googlePlayStore = 'https://play.google.com/store/apps/details?id=com.google.android.apps.forscience';
export const appStore = 'https://itunes.apple.com/us/app/forscience/id1459098983?mt=8';
export const twitter = 'https://twitter.com/forscience';
export const facebook = 'https://www.facebook.com/forscience';
export const instagram = 'https://www.instagram.com/forscience';
export const youtube = 'https://www.youtube.com/channel/UC-lHJZR3Gqxm24_Vd_AJ5Yw2';
